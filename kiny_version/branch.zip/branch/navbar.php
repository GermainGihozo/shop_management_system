<nav class="navbar navbar-expand-lg navbar-dark bg-secondary">
  <a class="navbar-brand" href="dashboard.php">Branch Panel</a>
  <div class="collapse navbar-collapse p-3">
    <ul class="navbar-nav">
      <li class="nav-item"><a class="nav-link" href="view_stock.php">Stock</a></li>
      <li class="nav-item"><a class="nav-link" href="sell_product.php">Sell</a></li>
      <li class="nav-item"><a class="nav-link" href="report.php">Report</a></li>
      <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
      <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
    </ul>
  </div>
</nav>
