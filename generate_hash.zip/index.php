<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome - Shop Management System</title>
    <link rel="stylesheet" href="branch/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            border-radius: 15px;
        }
    </style>
</head>
<body>

<!-- <?php include 'includes/navbar.php'; ?> -->

<div class="main-content">
    <div class="card shadow p-4 text-center">
        <h1 class="mb-3">Welcome to Shop Management System</h1>
        <p class="lead mb-4">Manage sales, branches, stock, and reports efficiently.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="login.php" class="btn btn-primary">Login as Admin</a>
            <a href="login.php" class="btn btn-success">Login as Branch User</a>
           <a href="kiny_version" class="btn btn-primary">Change language</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
