<!-- includes/footer.php -->
<footer class="bg-dark text-white mt-5 p-3 text-center">
    <div class="container">
        <p class="mb-1">&copy; <?= date('Y') ?> Shop Management System. All rights reserved.</p>
        <p class="mb-0">Developed by <strong>Germain Igihozo</strong></p>
    </div>
</footer>
